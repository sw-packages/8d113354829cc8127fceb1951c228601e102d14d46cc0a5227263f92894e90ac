// SPDX-License-Identifier: BSD-3-Clause
// Copyright Contributors to the OpenEXR Project.

#ifndef OPENEXR_CORE_TEST_BUFFER_H
#define OPENEXR_CORE_TEST_BUFFER_H

void testBufferCompression (const std::string& tempdir);

#endif // OPENEXR_CORE_TEST_BUFFER_H
